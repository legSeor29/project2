let nick = document.querySelector(".nickname")

nick.innerHTML = localStorage.getItem("login")
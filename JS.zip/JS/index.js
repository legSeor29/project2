function openPopup() {
    var popup = document.querySelector('.popup');
    popup.style.display = 'block';
  }
  function closePopup() {
    var popup = document.querySelector('.popup');
    popup.style.display = 'none';
  }
  function openPS() {
    document.location.replace('#PS');
    var popup = document.querySelector('.popup');
    popup.style.display = 'none';
  }
  function openXbox() {
    document.location.replace('#Xbox');
    var popup = document.querySelector('.popup');
    popup.style.display = 'none';
  }
  function openPC() {
    document.location.replace('#PC');
    var popup = document.querySelector('.popup');
    popup.style.display = 'none';
  }
  function contact_inf() {
    document.location.replace('#aboutus');
  }
  function openCart() {
    document.location.replace('cart.html');
  }
  function openMeetingPage() {
    document.location.replace('meetingpage.html');
  }